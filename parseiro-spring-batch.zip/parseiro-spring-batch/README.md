# parseiro2.0
parser-retorno-cnab240bb reimplementado utilizando spring-batch
