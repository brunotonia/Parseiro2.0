package br.com.brvt.parseirospringbatch.model;

public class Cnab240BB {
    
}
