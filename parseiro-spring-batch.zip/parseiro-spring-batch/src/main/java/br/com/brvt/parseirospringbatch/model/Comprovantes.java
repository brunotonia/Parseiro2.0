package br.com.brvt.parseirospringbatch.model;

public class Comprovantes {    

}
