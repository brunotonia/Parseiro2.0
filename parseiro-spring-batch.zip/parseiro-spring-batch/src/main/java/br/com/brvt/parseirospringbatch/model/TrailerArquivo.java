package br.com.brvt.parseirospringbatch.model;

public class TrailerArquivo extends Cnab240BB {
    
}
