package br.com.brvt.parseirospringbatch.model;

public class TrailerLoteAB extends Cnab240BB {
    
}
