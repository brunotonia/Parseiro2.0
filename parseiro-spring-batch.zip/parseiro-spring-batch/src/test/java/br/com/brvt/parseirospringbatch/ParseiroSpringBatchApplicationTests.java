package br.com.brvt.parseirospringbatch;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class ParseiroSpringBatchApplicationTests {

	@Test
	void contextLoads() {
	}

}
